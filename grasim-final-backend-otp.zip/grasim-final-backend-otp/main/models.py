from django.db import models
from django.utils import timezone
# import django
from django.conf import settings
from django.utils.timezone import activate
activate(settings.TIME_ZONE)
from django.contrib import admin
from django.contrib.auth.models import AbstractBaseUser, PermissionsMixin, BaseUserManager
from django.utils.translation import gettext_lazy
class CustomAccountManager(BaseUserManager):
    def create_user(self, email, password, **other_fields):
        other_fields.setdefault("is_active", True)
        if not email:
            raise ValueError(gettext_lazy("You must provide an email"))
        email = self.normalize_email(email)
        user = self.model(email = email, **other_fields)
        user.set_password(password)
        user.save()
        return user
    def create_superuser(self, email, password, **other_fields):
        other_fields.setdefault("is_superuser", True)
        other_fields.setdefault("is_staff", True)
        other_fields.setdefault("is_active", True)
        return self.create_user(email, password, **other_fields)
class NewUser(AbstractBaseUser, PermissionsMixin):
    email = models.EmailField( gettext_lazy("Email Address"), unique=True, )
    first_name = models.CharField(max_length=150, blank=True)
    username = models.CharField(max_length=150, blank=True, null=True)
    start_Date = models.DateTimeField(default=timezone.now)
    is_staff = models.BooleanField(default=False)
    is_active = models.BooleanField(default=False)
    objects = CustomAccountManager()
    USERNAME_FIELD = 'email'
    REQUIRED_FIELDS = []
    def __str__(self):
        return self.email


class Dosage(models.Model):
    user = models.ForeignKey(NewUser, on_delete=models.CASCADE, null=True)
    Target_hypo_Input = models.FloatField(blank=True, null=True)
    target_loose_pulp_viscosity = models.FloatField(blank=True, null=True)
    loose_pulp_viscosity_actual = models.FloatField(blank=True, null=True)
    date = models.DateField(default=timezone.now)
    time = models.TimeField(default=timezone.localtime)
    eop_prev1 = models.FloatField(blank=True, null=True)
    eop_prev2 = models.FloatField(blank=True, null=True)
    hypo_visc_prev2 = models.FloatField(blank=True, null=True)
    hypo_visc_prev1 = models.FloatField(blank=True, null=True)
    hypo_add_prev1 = models.FloatField(blank=True, null=True)
    target_hypo_addition = models.FloatField(blank=True, null=True)
    hypo2 = models.FloatField(blank=True, null=True)
    vf6_flow = models.FloatField(blank=True, null=True)


class DosageAdmin(admin.ModelAdmin):
    list_display = (
        'user', 'Target_hypo_Input', 'target_loose_pulp_viscosity', 
        'eop_prev1','eop_prev2', 'hypo_visc_prev2','hypo_visc_prev1',
        'hypo_add_prev1','hypo2', 'vf6_flow', 'date','time')


class SetTargetValue(models.Model):
    user = models.ForeignKey(NewUser, on_delete=models.CASCADE, null=True)
    target_hypo_viscosity = models.FloatField(blank=True, null=True)
    target_loose_puls_viscosity = models.FloatField(blank=True, null=True)
    created_at = models.DateTimeField(auto_now_add=True)

    class Meta:
        db_table = "SetTargetValue"
