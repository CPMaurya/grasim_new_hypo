from django.contrib import admin
from .models import *


class SetTargetValueList(admin.ModelAdmin):
    list_display = (
        'user', 'target_hypo_viscosity', 
        'target_loose_puls_viscosity', 'created_at')

# Register your models here.
admin.site.register(Dosage, DosageAdmin)
admin.site.register(NewUser)
admin.site.register(SetTargetValue, SetTargetValueList)