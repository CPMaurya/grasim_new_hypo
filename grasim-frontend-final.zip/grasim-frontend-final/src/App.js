import { BrowserRouter, Routes, Route, Outlet } from "react-router-dom";
import './App.css';
import Login from './login/login';
import Run from './run/run';



function App() {
  return (
    <>
      <BrowserRouter>
        <Routes>
          <Route path="/" element={<Login />} />
          <Route path="run" element={<Run />} />
        </Routes>
      </BrowserRouter>
      {/* <Run></Run> */}
    </>
  );
}

export default App;