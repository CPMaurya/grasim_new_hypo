import math


def calc_hypo(eop_prev1, Target_hypo_Input, hypo_visc_prev1, eop_prev2, vf6_flow):
    delta = eop_prev1 - Target_hypo_Input
    hypo1 = 0
    hypo2_val = 0
    if delta > 150:
        del_cal = delta - 150
        hypo2_val = 7.73395 * math.log(3.405994550408719 * del_cal)
    if eop_prev1 <= 537 and hypo_visc_prev1 < 492:
        hypo1 = (0.12280701754385964 * hypo_visc_prev1) + -38.421052631578945
    elif eop_prev1 <= 537 and 492 < hypo_visc_prev1 < 520:
        hypo1 = (0.35714285714285715 * hypo_visc_prev1) + -153.71428571428572
    elif eop_prev1 <= 537 and hypo_visc_prev1 > 520:
        hypo1 = (0.25 * hypo_visc_prev1) + -98
    elif 537 < eop_prev1 < 587 and hypo_visc_prev1 < 492:
        hypo1 = (0.05263157894736842 * hypo_visc_prev1) + -0.8947368421052602
    elif 537 < eop_prev1 < 587 and 492 < hypo_visc_prev1 < 520:
        hypo1 = (0.35714285714285715 * hypo_visc_prev1) + -145.71428571428572
    elif 537 < eop_prev1 < 587 and hypo_visc_prev1 > 520:
        hypo1 = (0.1875 * hypo_visc_prev1) + -57.5
    elif eop_prev1 >= 587 and hypo_visc_prev1 < 492:
        hypo1 = (0.08771929824561403 * hypo_visc_prev1) + -13.157894736842103
    elif eop_prev1 >= 587 and 492 < hypo_visc_prev1 < 520:
        hypo1 = (0.5714285714285714 * hypo_visc_prev1) + -251.1428571428571
    elif eop_prev1 >= 587 and hypo_visc_prev1 > 520:
        hypo1 = (0.3125 * hypo_visc_prev1) + -116.5

    hypo1 = hypo1 * (vf6_flow / 300)
    hypo2_val = hypo2_val * (vf6_flow / 300)
    # hypo1 = hypo1 + 20

    return hypo1, hypo2_val


def calc_hypo_new(eop_prev1, eop_prev2, hypo_visc_prev1, hypo_visc_prev2, loose_pulp_viscosity_actual,
                  loose_pulp_viscosity_target, hypo_add_prev1):
    eop_delta = eop_prev1 - eop_prev2
    hypo_delta = hypo_visc_prev1 - hypo_visc_prev2
    loose_pulp_delta = loose_pulp_viscosity_actual - loose_pulp_viscosity_target
    target_hypo_addition = (eop_delta / 10) + (hypo_delta / 10) + (loose_pulp_delta / 10)
    hypo_addition = hypo_add_prev1 + target_hypo_addition
    return hypo_addition
