from .models import *
from rest_framework import serializers


class DosageCreateSerializer(serializers.ModelSerializer):
    class Meta:
        model = Dosage
        fields = ('user','Target_hypo_Input',
        'target_loose_pulp_viscosity','eop_prev1',
        'eop_prev2','hypo_visc_prev2','hypo_visc_prev1',
        'hypo_add_prev1', 'hypo2','target_hypo_addition', 'vf6_flow')
class DosageSerializer(serializers.ModelSerializer):
    date = serializers.DateField(format="%d-%m-%y")
    class Meta:
        model = Dosage
        fields = "__all__"

    def to_representation(self, instance):
        response = super().to_representation(instance)
        response['time'] = instance.time.strftime("%H:%M:%S") if instance.time else None
        return response

class NewUserSerializer(serializers.ModelSerializer):
    class Meta:
        model = NewUser
        fields = "__all__"