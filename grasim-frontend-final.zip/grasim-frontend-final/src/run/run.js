import * as React from "react";
import "bootstrap/dist/css/bootstrap.min.css";
import "./run.css";
import grasim from "./images/grasin.png";
import { useNavigate } from "react-router-dom";
import { useState, useEffect, useRef } from "react";
import TextField from "@mui/material/TextField";
import Stack from "@mui/material/Stack";
import axios from "axios";
import { Tooltip } from "@material-tailwind/react";
import moment from "moment";
import {
  BASE_API_URL,
  USER_API,
  DOSAGE_ALL_API,
  EXPORT_CSV_DAY_API,
  EXPORT_CSV_RANGE_API,
  AUTO_RUN,
  UPDATE_URL,
  MANUAL_URL,
} from "../constants/api";

function Homepage1() {
  // const [r1, setR1] =
  const myInterval = useRef(null);
  const [id, setData] = React.useState(
    JSON.parse(localStorage.getItem("user_id"))
  );
  const [eop_prev2, setr1] = React.useState("");
  const [eop_prev1, setr2] = useState("");
  const [hypo_visc_prev2, setr3] = useState("");
  const [hypo_visc_prev1, setr4] = useState("");
  const [hypo_add_prev1, setr5] = useState("");
  const [vf6_flow, setr6] = useState("");
  const [target_loose_pulp_viscosity, setpulp] = useState("450");
  const [Target_hypo_Input, sethypo] = useState("");
  const [run_button, setrun_button] = React.useState(false);
  const [hist, sethist] = React.useState(false);
  const [manualRun, setManualRun] = React.useState(false);
  const [from, setfrom] = React.useState(
    moment(new Date()).format("YYYY-MM-DD")
  );
  const [to, setto] = React.useState(moment(new Date()).format("YYYY-MM-DD"));
  const [from1, setfrom1] = React.useState(
    moment(new Date()).format("DD-MM-YYYY")
  );
  const [to1, setto1] = React.useState(moment(new Date()).format("DD-MM-YYYY"));
  const [date, setDate] = useState(moment(new Date()).format("YYYY-MM-DD"));
  const [time, settime] = useState(moment().format("HH:mm:ss"));
  const [pr, setpr] = useState("");
  const navigate = useNavigate();
  const [sheet, setData1] = useState("");
  const [target_hypo_addition_final, setTarget_hypo_addition_final] =
    useState("");

  const [hypo2, setHypo2] = useState();
  const [active, setActive] = useState(1);
  const [hypoAddition, setHypoAddition] = useState("");
  const [stopCalling, setStopCalling] = useState(false);
  const [timeDuration, setTimeDuration] = useState(300);
  const [updatedTime, setUpdatedTime] = useState("");
  const [updatedDate, setUpdatedDate] = useState("");
  const [recommend, setRecommend] = useState([]);

  const autoRun = async () => {
    // console.log("INSIDE AUTORUN");
    const call = await fetch(`${BASE_API_URL}/${AUTO_RUN}`, {
      method: "GET",
      // headers: {
      //     'Accept': 'application/json',
      //     'Content-Type': 'application/json',
      // },
      // body: JSON.stringify({
      //     "TRP2_outlet_consistency_2hr_lag": new Number(r1),
      //     "D0_H2SO4_flow_2hr_lag": new Number(r2),
      //     "D0_inlet_Kappa_Number_2hr_lag": new Number(r3),
      //     "Do_pH_Filtarte_2hr_lag": new Number(r4),
      //     "TRP_2_Viscosity_2hr_lag": new Number(r5),
      //     "PO2_Press_Pulp_Consistency_2hr_lag": new Number(r6),
      //     "Do_Tower_Inlet_Temperature_2hr_lag": new Number(r7),
      //     "PO_2_Press_Pulp_Flow_2hr_lag": new Number(r8),
      //     "d0_outlet_brightness": new Number(r9),
      //     "ClO2_concentration": new Number(Target_hypo_Input),
      //     "trp2_outlet_brightness": new Number(target_loose_pulp_viscosity),
      // })
    });

    const res = await call.json();

    // temp = {
    //     "EOP_viscosity_n-2": 6,
    //     "EOP_viscosity_n-1": 6,
    //     "Hypo_viscosity_n-2": 6,
    //     "Hypo_viscosity_n-1": 6,
    //     "Prev_Hypo_Addition": 6,
    //     "Target_Hypo_viscosity(previous)": 490,
    //     "Target_Loose_pulp_viscosity": 450,
    //     "Recommended_Hypo_Addition": -15.390181818181857,
    //     "Recommended_Hypo_Secondary": 0
    // }

    setr1(Number(res["EOP_viscosity_n-2"]));
    setr2(Number(res["EOP_viscosity_n-1"]));
    setr3(Number(res["Hypo_viscosity_n-2"]));
    setr4(Number(res["Hypo_viscosity_n-1"]));
    setr5(Number(res["Prev_Hypo_Addition"]));
    setr6(Number(res["VF6_Flow"]));
    // sethypo(Number(res["Target_Hypo_viscosity(previous)"]));
    sethypo(0);
    // setpulp(Number(res["Target_Loose_pulp_viscosity"]));
    setpulp("450");
    setHypoAddition(Number(res["Recommended_Hypo_Addition"])?.toFixed(2));
    // setData1((prev)=> ({...prev ,
    //     hypo_addition : res["Recommended_Hypo_Addition"].toFixed(2)}))
    setHypo2(Number(res["Recommended_Hypo_Secondary"]));
    setUpdatedTime(res["updated_at"]);
    // setUpdatedDate(res["updated_at"].split(',')[0])
    setRecommend(res["error sensors"]);
    // setData2(res[""])
    // const val = res.success
    // setData1(res.success)
    // console.log("value", res.success)
    // if (res.success) {
    // const call = await fetch(`${BASE_API_URL}clo2_dosage/all/`, {
    //     method: "POST",
    //     headers: {
    //         'Accept': 'application/json',
    //         'Content-Type': 'application/json',
    //     },
    //     body: JSON.stringify({
    //     TRP2_outlet_consistency_2hr_lag: r1,
    //     D0_H2SO4_flow_2hr_lag: r2,
    //     D0_inlet_Kappa_Number_2hr_lag: r3,
    //     Do_pH_Filtarte_2hr_lag: r4,
    //     TRP_2_Viscosity_2hr_lag: r5,
    //     PO2_Press_Pulp_Consistency_2hr_lag: r6,
    //     Do_Tower_Inlet_Temperature_2hr_lag: r7,
    //     PO_2_Press_Pulp_Flow_2hr_lag: r8,
    //     d0_outlet_brightness: r9,
    //     ClO2_concentration: Target_hypo_Input,
    //     trp2_outlet_brightness: target_loose_pulp_viscosity,
    //     recommended_dosage: String(val),
    //     date: date,
    //     time: time,

    //     })
    // })
    // const resp = await call.json()
    // setrun_button(true)
    // axios
    //     .get(`${BASE_API_URL}/${USER_API}`, {
    //         params: {
    //             id: id
    //         }
    //     })
    //     .then((response) => {
    //         // console.log('do all =', response)
    //         setpr(response.data.dosages);
    //     })
    //     .catch((err) => console.log(err));
    // }

    const newUser = {
      Target_hypo_Input: res["Target_Hypo_viscosity"],
      target_loose_pulp_viscosity: res["Target_Loose_pulp_viscosity"],
      eop_prev1: res["EOP_viscosity_n-1"],
      eop_prev2: res["EOP_viscosity_n-2"],
      hypo_add_prev1: res["Prev_Hypo_Addition"],
      hypo_visc_prev1: res["Hypo_viscosity_n-1"],
      hypo_visc_prev2: res["Hypo_viscosity_n-2"],
      vf6_flow: res["VF6_Flow"],
      user: id,
      target_hypo_addition: res["Recommended_Hypo_Addition"].toFixed(2),
      date: date,
      time: time,
      hypo2: res["Recommended_Hypo_Secondary"],
    };
    // console.log("user", newUser);
    // console.log(date);
    // axios
    //     .post(`${BASE_API_URL}/${DOSAGE_ALL_API}`, newUser)
    //     .then((response) => {
    //     })
    //     .catch((err) => alert("There seems to be an error, kindly inform the development team"));

    setTimeout(() => {
      axios
        .get(`${BASE_API_URL}/${USER_API}`, {
          params: {
            id: id,
          },
        })
        .then((response) => {
          //   console.log("Call after run", response);
          setpr(response.data.dosages);
        })
        .catch((err) => console.log(err));
    }, 1000);
  };

  // useEffect(() => {
  //   autoRun();
  // }, []);

  useEffect(() => {
    if (stopCalling === false) {
      //   console.log("INSIDE INTERVAL IF", stopCalling);
      autoRun();
      myInterval.current = setInterval(() => {
        // console.log('INSIDE INTERVAL', stopCalling)
        autoRun();
      }, timeDuration * 1000);
    } else {
      //   console.log("INSIDE INTERVAL ELSE", stopCalling, intId);
      clearInterval(myInterval.current);
      myInterval.current = null;
    }
  }, [stopCalling]);

  const showInfo = () => {
    var hypo_addition = 0;
    var Target_hypo = 450;
    var delta = eop_prev1 - Target_hypo_Input;
    var hypo1 = 0;
    var hypo2_val = 0;
    if (delta > 150) {
      var del_cal = delta - 150;
      hypo2_val = 7.73395 * Math.log(3.405994550408719 * del_cal);
      setHypo2(hypo2_val);
    }
    if (eop_prev1 < 510 && hypo_visc_prev1 < 470) {
      hypo1 = 0.06515909090909099 * eop_prev1 + -15.781136363636403;
    } else if (eop_prev1 < 510 && hypo_visc_prev1 > 470) {
      hypo1 = 0.06472727272727279 * eop_prev1 + -14.190909090909116;
    } else if (510 < eop_prev1 < 620 && hypo_visc_prev1 < 470) {
      hypo1 = 0.0936363636363637 * eop_prev1 + -31.704545454545492;
    } else if (510 < eop_prev1 < 620 && 470 < hypo_visc_prev1 < 540) {
      hypo1 = 0.13709090909090924 * eop_prev1 + -45.79636363636371;
    } else if (510 < eop_prev1 < 620 && hypo_visc_prev1 > 540) {
      hypo1 = 0.13727272727272735 * eop_prev1 + -34.80909090909094;
    } else if (eop_prev2 > 620 && hypo_visc_prev1 < 470) {
      hypo1 = 0.16718749999999966 * eop_prev1 + -57.68124999999976;
    } else if (eop_prev2 > 620 && 470 < hypo_visc_prev1 < 540) {
      hypo1 = 0.16718749999999966 * eop_prev1 + -57.68124999999976;
    } else if (eop_prev2 > 620 && hypo_visc_prev1 > 540) {
      hypo1 = 0.11143749999999988 * eop_prev1 + -15.2562499999999;
    }

    {
      /*if (eop_prev1<450){
            hypo_addition = 10;
        }
        else if (eop_prev1>=450 && eop_prev1<500){
            hypo_addition = 0.13*eop_prev1 - 44;
        }
        else if (eop_prev1>=500 && eop_prev1<550){
            hypo_addition = 0.17*eop_prev1 - 64;
        }
        else if (eop_prev1>=550 && eop_prev1<600){
            hypo_addition = 0.18*eop_prev1 - 70;
        }
        else if (eop_prev1>=600 && eop_prev1<650){
            hypo_addition = 0.34*eop_prev1 - 166;
        }
        else if (eop_prev1>=650 && eop_prev1<700){
            hypo_addition = 0.40*eop_prev1 - 205;
        }
        else{
            hypo_addition = 70;
        }
    
        var bias = 0;
        if (hypo_visc_prev1>=510){
            bias = 0.5*hypo_visc_prev1 - 250;
        }
        else if(hypo_visc_prev1<=490){
            bias = 0.5*hypo_visc_prev1 - 250;
        }*/
    }

    hypo_addition = hypo1;
    var str = "";

    str +=
      "<h2>Target Loose Pulp Viscosity = " +
      target_loose_pulp_viscosity +
      "<br></h2>";
    if (hypo_addition < 0.0) {
      str += "<h2>Recommended Hypo Dosage Value less than zero<br></h2>";
    } else {
      str +=
        "<h2>Recommended Hypo Dosage: " +
        hypo_addition.toFixed(2) +
        " L/min<br></h2>";
    }

    {
      /*if (delta>150){
            str += "<h2>Secondary Hypo Dosage is" + hypo2.toFixed(2) + "<br></h2>";
        }*/
    }
    Target_hypo = Target_hypo_Input;
    var d = {
      str: str,
      Target_hypo_Input: Target_hypo_Input,
      Target_hypo: Target_hypo,
      target_loose_pulp_viscosity: target_loose_pulp_viscosity,
      hypo_addition: hypo_addition.toFixed(1),
      hypo_2: hypo2_val,
      vf6_flow: vf6_flow,
    };

    setData1(d);
    // setTarget_hypo_addition_final(d.hypo_addition.toFixed(1));
    // console.log(d.hypo_addition);
    // console.log(target_hypo_addition_final)

    if (run_button === false) {
      setrun_button(true);
      console.log(date);
      console.log(time);
      console.log(d.hypo_2);
      const newUser = {
        Target_hypo_Input: Target_hypo_Input,
        target_loose_pulp_viscosity: target_loose_pulp_viscosity,
        eop_prev1: eop_prev1,
        eop_prev2: eop_prev2,
        hypo_add_prev1: hypo_add_prev1,
        hypo_visc_prev1: hypo_visc_prev1,
        hypo_visc_prev2: hypo_visc_prev2,
        vf6_flow: vf6_flow,
        user: id,
        target_hypo_addition: d.hypo_addition,
        date: date,
        time: time,
        hypo2: d.hypo_2,
      };

      console.log("user", newUser);
      // console.log(date);
      axios
        .post(`${BASE_API_URL}/${DOSAGE_ALL_API}`, newUser)
        .then((response) => {})
        .catch((err) =>
          alert(
            "There seems to be an error, kindly inform the development team"
          )
        );
      setTimeout(() => {
        axios
          .get(`${BASE_API_URL}/${USER_API}`, {
            params: {
              id: id,
            },
          })
          .then((response) => {
            console.log("Call after run", response);
            setpr(response.data.dosages);
          })
          .catch((err) => console.log(err));
      }, 1000);
    } else {
      setrun_button(false);
      setr1("");
      setr2("");
      setr3("");
      setpulp("450");
      sethypo("");
      setr4("");
      setr5("");
      setr6("");
    }
  };

  useEffect(() => {
    if (active === 1) {
      // autoRun();
      sethist(false);
    } else {
      sethist(true);
    }

    if (active === 3) {
      setStopCalling(true);
      setr1(0);
      setr2(0);
      setr3(0);
      setr4(0);
      setr5(0);
      setr6(0);
      sethypo(0);
      setpulp("450");
      setHypoAddition(0);
      setHypo2(0);
      setRecommend([]);
    } else {
      setStopCalling(false);
    }
  }, [active]);

  const handleUpdate = async () => {
    console.log("handle update");
    const call = await fetch(`${BASE_API_URL}/${UPDATE_URL}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "Target_Hypo_viscosity(previous)": 500,
        Target_Loose_pulp_viscosity: Number(target_loose_pulp_viscosity),
      }),
    });
    const resp = await call.json();
    if (active !== 3) setStopCalling(false);
  };

  const handleManualRun = async () => {
    const call = await fetch(`${BASE_API_URL}/${MANUAL_URL}`, {
      method: "POST",
      headers: {
        Accept: "application/json",
        "Content-Type": "application/json",
      },
      body: JSON.stringify({
        "EOP_viscosity_n-2": Number(eop_prev2),
        "EOP_viscosity_n-1": Number(eop_prev1),
        "Hypo_viscosity_n-2": Number(hypo_visc_prev2),
        "Hypo_viscosity_n-1": Number(hypo_visc_prev1),
        Prev_Hypo_Addition: Number(hypo_add_prev1),
        // "Target_Hypo_viscosity(previous)": Number(Target_hypo_Input),
        Target_Loose_pulp_viscosity: Number(target_loose_pulp_viscosity),
        VF6_Flow: Number(vf6_flow),
      }),
    });
    const resp = await call.json();
    setHypoAddition(resp.Recommended_Hypo_Addition);
    setHypo2(resp.Recommended_Hypo_Secondary);
  };

  const handleChange1 = (event) => {
    setfrom(event.target.value);
  };
  const handleChange2 = (event) => {
    setto(event.target.value);
  };

  const handlehist1 = () => {
    if (hist === true) {
      sethist(false);
      console.log(id);
    }
    console.log(id);
  };

  const handlehist2 = () => {
    if (hist === false) {
      sethist(true);
      console.log(id);
    }
    console.log(pr);
  };

  const updater1 = (event) => {
    setr1(event.target.value);
  };

  const updater2 = (event) => {
    setr2(event.target.value);
  };

  const updater3 = (event) => {
    setr3(event.target.value);
  };

  const updater4 = (event) => {
    setr4(event.target.value);
  };

  const updater5 = (event) => {
    setr5(event.target.value);
  };
  const updater6 = (event) => {
    setr6(event.target.value);
  };

  const updatepulp = (event) => {
    setpulp(event.target.value);
  };
  const updateTimeDuration = (event) => {
    setTimeDuration(event.target.value);
  };

  const updatehypo = (event) => {
    sethypo(event.target.value);
  };
  const csvdownload = () => {
    window.location.replace(`${BASE_API_URL}/${EXPORT_CSV_DAY_API}=${id}`);
  };
  const csvdownload2 = () => {
    // window.location.replace('https://www.ripik-line-balancer-backend.com/main/export_from_to_csv/?end_date=' + to1 + '&start_date='+ from1 +'&id=' + id );
    window.location.replace(
      BASE_API_URL +
        EXPORT_CSV_RANGE_API +
        to1 +
        "&start_date=" +
        from1 +
        "&id=" +
        id
    );
  };

  useEffect(() => {
    const [year1, month1, day1] = to.split("-");
    setto1(day1 + "-" + month1 + "-" + year1);
    const [year, month, day] = from.split("-");
    setfrom1(day + "-" + month + "-" + year);
    setData(JSON.parse(localStorage.getItem("user_id")));
    setDate(moment(new Date()).format("YYYY-MM-DD"));
    settime(new Date().toLocaleTimeString());
    axios
      .get(`${BASE_API_URL}/${USER_API}`, {
        params: {
          id: id,
        },
      })
      .then((response) => {
        // console.log("do all =", response);
        setpr(response.data.dosages);
      })
      .catch((err) => console.log(err));
    // console.log(pr);
  }, []);

  return (
    <>
      <div className="row r_back_img">
        <div className="flex justify-between mb-1 items-center">
          <div className="flex items-center gap-4">
            <img src={grasim} className="pl-2 pt-2 h-20 w-32"></img>
            <div className="text-2xl text-blue-500">
              Hypo Dosage Model for Harihar Plant
            </div>
          </div>

          <div
            onClick={() => navigate("/")}
            className="cursor-pointer h-10 px-6 text-white pt-2 hover:bg-blue-600  rounded-md bg-blue-400 "
          >
            Logout
          </div>
        </div>

        <div className="flex justify-center mb-2">
          <div className="h-20 w-96 border rounded-full bg-blue-500 grid grid-cols-3 border-blue-500 shadow-xl">
            <div
              onClick={() => setActive(1)}
              className={
                active === 1
                  ? "h-20 flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white shadow-xl text-white border border-2 rounded-l-full py-0.5"
                  : "h-20 flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-l-full py-0.5 text-black hover:bg-blue-300"
              }
            >
              Run
            </div>
            <div
              onClick={() => setActive(2)}
              className={
                active === 2
                  ? "h-20 flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white border border-2 shadow-xl text-white py-0.5"
                  : "h-20 flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 py-0.5 hover:bg-blue-300"
              }
            >
              History
            </div>
            <div
              onClick={() => setActive(3)}
              className={
                active === 3
                  ? "h-20 flex items-center cursor-pointer justify-center items-center bg-blue-500 font-bold border-white border border-2 shadow-xl text-white rounded-r-full py-0.5"
                  : "h-20 flex items-center cursor-pointer border border-white border-2 justify-center font-bold bg-gray-300 rounded-r-full py-0.5 hover:bg-blue-300"
              }
            >
              Manual
            </div>
          </div>
        </div>
        {active === 1 && (
          <div>
            <div className="grid grid-cols-12 r_run_box  border-[#2f8fe9] border-1 shadow-xl rounded-2xl m-20 bg-white m-20">
              <div className="col-span-7 p-2">
                <div className="flex justify-between items-center px-2">
                  <div className="text-blue-500 text-2xl pl-3 pt-2 pb-2">
                    Input Data{" "}
                  </div>
                  <div className="flex mb-3 mt-3 items-center justify-center">
                    <div className="text-blue-500 text-sm mr-2">
                      Updated at :{" "}
                    </div>
                    <div className="text-sm bg-blue-600 text-white p-2 rounded-xl font-bold">
                      {" "}
                      {updatedTime}{" "}
                    </div>
                    {/* <div className='text-blue-500 text-sm'>Updated on : {updatedDate} </div> */}
                  </div>
                </div>
                <div className="border border-dashed border-2 rounded-xl  pt-2 pb-2">
                  <div className="row items-center justify-around">
                    <div className="col-6 r_eop_text">EOP viscosity n-2:</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={eop_prev2}
                        onChange={updater1}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={eop_prev2}
                        onChange={updater1}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">EOP viscosity n-1:</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={eop_prev1}
                        onChange={updater2}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={eop_prev1}
                        onChange={updater2}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Hypo viscosity n-2:</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_visc_prev2}
                        onChange={updater3}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_visc_prev2}
                        onChange={updater3}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Hypo viscosity n-1:</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_visc_prev1}
                        onChange={updater4}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_visc_prev1}
                        onChange={updater4}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Prev Hypo Addition :</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_add_prev1}
                        onChange={updater5}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={hypo_add_prev1}
                        onChange={updater5}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">VF6 Flow :</div>
                    {stopCalling ? (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={vf6_flow}
                        onChange={updater6}
                      />
                    ) : (
                      <input
                        className="col-5 r_eop_box"
                        type="number"
                        value={vf6_flow}
                        onChange={updater6}
                        readOnly
                      />
                    )}
                  </div>
                  <div className="border-2 border-dashed border-blue-400 rounded-lg p-2 m-1">
                    {/* <div className="row items-center justify-around p-0.5">
                      <div className="col-6 r_eop_text">
                        Target Hypo viscosity(previous):
                      </div>
                      {stopCalling ? (
                        <input
                          className="col-5 r_hypo_box ml-1"
                          type="number"
                          value={Target_hypo_Input}
                          onChange={updatehypo}
                        />
                      ) : (
                        <input
                          className="col-5 r_hypo_box ml-1"
                          type="number"
                          value={Target_hypo_Input}
                          onChange={updatehypo}
                          readOnly
                        />
                      )}
                    </div> */}
                    <div className="row items-center justify-around p-0.5">
                      <div className="col-6 r_eop_text">
                        Target Loose pulp viscosity:
                      </div>
                      {stopCalling ? (
                        <input
                          className="col-5 r_hypo_box"
                          type="number"
                          value={target_loose_pulp_viscosity}
                          onChange={updatepulp}
                          readOnly
                        />
                      ) : (
                        <input
                          className="col-5 r_hypo_box"
                          type="number"
                          value={target_loose_pulp_viscosity}
                          onChange={updatepulp}
                          readOnly
                        />
                      )}
                    </div>
                    <div className="row items-center justify-around p-0.5">
                      <div className="col-6 r_eop_text">Time Duration(s):</div>
                      {stopCalling ? (
                        <input
                          className="col-5 r_hypo_box"
                          type="number"
                          value={timeDuration}
                          onChange={updateTimeDuration}
                        />
                      ) : (
                        <input
                          className="col-5 r_hypo_box"
                          type="number"
                          value={timeDuration}
                          onChange={updateTimeDuration}
                          readOnly
                        />
                      )}
                    </div>
                  </div>
                  <div className="flex justify-center items-center">
                    {stopCalling ? (
                      <div
                        onClick={() => (handleManualRun(), handleUpdate())}
                        className="rounded-lg bg-blue-500 text-white p-2 cursor-pointer font-bold"
                      >
                        {" "}
                        UPDATE
                      </div>
                    ) : (
                      <div className="rounded-lg bg-gray-300 p-2 font-bold">
                        <Tooltip
                          animate={{
                            mount: { scale: 1, y: 0 },
                            unmount: { scale: 0, y: 0 },
                          }}
                          content="Please STOP the process before updating"
                          placement="top"
                          className="bg-blue-500 font-semibold text-3xl w-56 text-sm p-2"
                        >
                          UPDATE
                        </Tooltip>
                      </div>
                    )}
                  </div>
                </div>

                <div className="flex justify-center items-center m-2">
                  {!stopCalling ? (
                    <div
                      onClick={() => setStopCalling(true)}
                      className="bg-red-600 text-white font-bold p-2 rounded-xl cursor-pointer"
                    >
                      STOP
                    </div>
                  ) : null}
                </div>
                {/* <div className='row r_run_button'>

                                {run_button === false &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RUN</div></div>
                                }
                                {run_button === true &&
                                    <div className='r_run_button_text' onClick={() => showInfo()}><div>RESET</div></div>
                                }
                            </div> */}
              </div>
              {/* <div className="col-span-1 vl bg-yellow-500"></div> */}
              <div className="border-l-2 border-[#2f8fe9] col-span-5 p-2 my-2">
                <div className="text-blue-500 text-3xl pl-6 pt-6">Results</div>
                {hypoAddition !== "" && (
                  <div className="">
                    {/* row r_reading_display */}
                    <div className=" flex flex-col items-center justify-center bg-green-300  rounded-3xl  p-12 shadow-lg m-auto w-[50%] h-[50%]">
                      {/* r_reading_display_text */}
                      <div className="text-green-600 font-bold text-xl">
                        Target Hypo Addition
                      </div>
                      <div className="text-green-600 font-bold text-3xl">
                        {Number(hypoAddition)?.toFixed(2)}
                      </div>
                    </div>
                    {/* <div className="row r_loose_vis flex items-center justify-center mb-3 mt-3">
                      Target Hypo Addition
                    </div> */}
                    {typeof hypo2 !== "undefined" ? (
                      <div className="flex items-center justify-center p-12 gap-2">
                        <div
                          // style={{ marginTop: "65px" }}
                          className=" font-bold text-xl "
                        >
                          Recommended Secondary Hypo Dosage:
                        </div>
                        <div className="text-green-600 text-2xl font-bold ">
                          {Number(hypo2)?.toFixed(2)}
                        </div>
                      </div>
                    ) : null}
                    {recommend.length !== 0 ? (
                      <div className="text-red-500 text-center">
                        Bad request due to following sensors:{" "}
                        {recommend.map((item) => (
                          <p>
                            {item}
                            <br></br>
                          </p>
                        ))}{" "}
                      </div>
                    ) : null}
                    {/* <div style={{ marginTop: '-7px' }} className='row r_download_button'>
                                        <div className='r_run_button_text' onClick={() => csvdownload()}><div>DOWNLOAD</div></div>
                                    </div> */}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        {active === 2 && (
          <div>
            <div className=" r_run_box border-[#2f8fe9] border-1 shadow-xl rounded-2xl m-20 bg-white">
              <div className="flex justify-around">
                <div className="r_run_t1">History</div>
                <div className=" r_date_box">
                  <Stack>
                    <TextField
                      label="FROM"
                      type="date"
                      value={from}
                      onChange={handleChange1}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Stack>
                </div>
                <div className=" r_date_box">
                  <Stack>
                    <TextField
                      label="TO"
                      type="date"
                      value={to}
                      onChange={handleChange2}
                      InputLabelProps={{
                        shrink: true,
                      }}
                    />
                  </Stack>
                </div>
                <div className=" r_download_button2">
                  <div
                    className="r_run_button_text1"
                    onClick={() => csvdownload2()}
                  >
                    <div>Download</div>
                  </div>
                </div>
              </div>
              <div className="h-120 rounded-xl p-2 my-2 m-auto">
                <div
                  className="h-200 overflow-x-scroll overflow-y-scroll m-2 border-dashed border-2 p-2 pt-0"
                  style={{ height: "400px", width: "" }}
                >
                  <table className="relative w-full">
                    <tr className="">
                      <th className="sticky top-0  text-center rounded-l-lg text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Date
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Time
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Target Hypo Input
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Target Loose Pulp
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        EOP(n-2)
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        EOP(n-1)
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Hypo Vis.(n-2)
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Hypo Vis.(n-1)
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        VF6 Flow
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Previous hypo addition
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Actual hypo addition
                      </th>
                      <th className="sticky top-0  text-center text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Recommended Hypo Addition
                      </th>
                      <th className="sticky top-0  text-center rounded-r-lg text-sm border-dashed border-1 p-2 bg-blue-600 text-white font-bold">
                        Recommended Hypo Secondary
                      </th>
                    </tr>
                    {[...pr].reverse().map((val1, key) => {
                      return (
                        <tr key={key}>
                          <th className="color_back text-center border-1 border-black">
                            {val1.date}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.time}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.Target_hypo_Input}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.target_loose_pulp_viscosity}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.eop_prev2}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.eop_prev1}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.hypo_visc_prev2}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.hypo_visc_prev1}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.vf6_flow}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.prev_hypo_addition?.toFixed(2)}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.actual_hypo_addition?.toFixed(2)}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.target_hypo_addition?.toFixed(2)}
                          </th>
                          <th className="color_back text-center border-1 border-black">
                            {val1.hypo2?.toFixed(2)}
                          </th>
                        </tr>
                      );
                    })}
                  </table>
                </div>
              </div>
            </div>
          </div>
        )}
        {active === 3 && (
          <div>
            <div className="grid grid-cols-12 r_run_box  border-[#2f8fe9] border-1 shadow-xl rounded-2xl m-20 bg-white m-20">
              <div className="col-span-7 p-2">
                <div className="flex justify-between items-center px-2">
                  <div className="text-blue-500 text-2xl pl-3 pt-2 pb-2">
                    Input Data{" "}
                  </div>
                  {/* <div className="flex mb-3 mt-3 items-center justify-center">
                    <div className="text-blue-500 text-sm mr-2">
                      Updated at :{" "}
                    </div>
                    <div className="text-sm bg-blue-600 text-white p-2 rounded-xl font-bold">
                      {" "}
                      {updatedTime}{" "}
                    </div>
                  </div> */}
                </div>
                <div className="border border-dashed border-2 rounded-xl  pt-2 pb-2">
                  <div className="row items-center justify-around">
                    <div className="col-6 r_eop_text">EOP viscosity n-2:</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={eop_prev2}
                      onChange={updater1}
                    />
                  </div>
                  <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">EOP viscosity n-1:</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={eop_prev1}
                      onChange={updater2}
                    />
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Hypo viscosity n-2:</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={hypo_visc_prev2}
                      onChange={updater3}
                    />
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Hypo viscosity n-1:</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={hypo_visc_prev1}
                      onChange={updater4}
                    />
                  </div>
                  <div className="row items-center justify-around p-0.5 ">
                    <div className="col-6 r_eop_text">Prev Hypo Addition :</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={hypo_add_prev1}
                      onChange={updater5}
                    />
                  </div>
                  <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">VF6 Flow :</div>
                    <input
                      className="col-5 r_eop_box"
                      type="number"
                      value={vf6_flow}
                      onChange={updater6}
                    />
                  </div>
                  {/* <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">
                      Target Hypo viscosity(previous):
                    </div>
                    <input
                      className="col-5 r_hypo_box ml-1"
                      type="number"
                      value={Target_hypo_Input}
                      onChange={updatehypo}
                    />
                  </div> */}
                  <div className="row items-center justify-around p-0.5">
                    <div className="col-6 r_eop_text">
                      Target Loose pulp viscosity:
                    </div>
                    <input
                      className="col-5 r_hypo_box"
                      type="number"
                      value={target_loose_pulp_viscosity}
                      onChange={updatepulp}
                      readOnly
                    />
                  </div>
                  <div className="flex justify-center items-center">
                    <div
                      onClick={() => handleManualRun()}
                      className="rounded-lg bg-blue-500 text-white p-2 cursor-pointer font-bold"
                    >
                      {" "}
                      RUN
                    </div>
                  </div>
                </div>
              </div>
              <div className="border-l-2 border-[#2f8fe9] col-span-5 p-2 my-2">
                <div className="text-blue-500 text-3xl pl-6 pt-6">Results</div>
                {hypoAddition !== "" && (
                  <div className="">
                    {/* row r_reading_display */}
                    <div className=" flex flex-col items-center justify-center bg-green-300  rounded-3xl  p-12 shadow-lg m-auto w-[50%] h-[50%]">
                      {/* r_reading_display_text */}
                      <div className="text-green-600 font-bold text-xl">
                        Target Hypo Addition
                      </div>
                      <div className="text-green-600 font-bold text-3xl">
                        {Number(hypoAddition)?.toFixed(2)}
                      </div>
                    </div>
                    {/* <div className="row r_loose_vis flex items-center justify-center mb-3 mt-3">
                      Target Hypo Addition
                    </div> */}
                    {typeof hypo2 !== "undefined" ? (
                      <div className="flex items-center justify-center p-12 gap-2">
                        <div
                          // style={{ marginTop: "65px" }}
                          className=" font-bold text-xl "
                        >
                          Recommended Secondary Hypo Dosage:
                        </div>
                        <div className="text-green-600 text-2xl font-bold ">
                          {Number(hypo2)?.toFixed(2)}
                        </div>
                      </div>
                    ) : null}
                    {recommend.length !== 0 ? (
                      <div className="text-red-500 text-center">
                        Bad request due to following sensors:{" "}
                        {recommend.map((item) => (
                          <p>
                            {item}
                            <br></br>
                          </p>
                        ))}{" "}
                      </div>
                    ) : null}
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
        <div className="row ">
          <div className="r_ripik">Powered by Ripik.ai</div>
        </div>
      </div>
    </>
  );
}

export default Homepage1;
