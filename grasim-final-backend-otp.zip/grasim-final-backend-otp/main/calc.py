import math


def calc_hypo(eop_prev1, Target_hypo_Input, hypo_visc_prev1, eop_prev2, vf6_flow):
    delta = eop_prev1 - Target_hypo_Input
    hypo1 = 0
    hypo2_val = 0
    if delta > 150:
        del_cal = delta - 150
        hypo2_val = 7.73395 * math.log(3.405994550408719 * del_cal)
    if eop_prev1 <= 540 and hypo_visc_prev1 < 446:
        hypo1 = (0.3055555555555556 * hypo_visc_prev1) + -105.2777777777778
    elif eop_prev1 <= 540 and 446 < hypo_visc_prev1 < 480:
        hypo1 = (0.38235294117647056 * hypo_visc_prev1) + -142.52941176470586
    elif eop_prev1 <= 540 and hypo_visc_prev1 > 480:
        hypo1 = (0.21428571428571427 * hypo_visc_prev1) + -65.85714285714285
    elif 540 < eop_prev1 < 578 and hypo_visc_prev1 < 446:
        hypo1 = (0.3333333333333333 * hypo_visc_prev1) + -111.66666666666666
    elif 540 < eop_prev1 < 578 and 446 < hypo_visc_prev1 < 480:
        hypo1 = (0.47058823529411764 * hypo_visc_prev1) + -175.88235294117646
    elif 540 < eop_prev1 < 578 and hypo_visc_prev1 > 480:
        hypo1 = (0.2857142857142857 * hypo_visc_prev1) + -97.14285714285714
    elif eop_prev1 >= 578 and hypo_visc_prev1 < 446:
        hypo1 = (0.4722222222222222 * hypo_visc_prev1) + -163.61111111111111
    elif eop_prev1 >= 578 and 446 < hypo_visc_prev1 < 480:
        hypo1 = (0.4411764705882353 * hypo_visc_prev1) + -156.76470588235293
    elif eop_prev1 >= 578 and hypo_visc_prev1 > 480:
        hypo1 = (0.38571428571428573 * hypo_visc_prev1) + -137.14285714285714

    hypo1 = hypo1 * (vf6_flow / 300)
    hypo2_val = hypo2_val * (vf6_flow / 300)
    # hypo1 = hypo1 + 20

    return hypo1, hypo2_val


def calc_hypo_new(eop_prev1, eop_prev2, hypo_visc_prev1, hypo_visc_prev2, loose_pulp_viscosity_actual,
                  loose_pulp_viscosity_target, hypo_add_prev1):
    eop_delta = eop_prev1 - eop_prev2
    hypo_delta = hypo_visc_prev1 - hypo_visc_prev2
    loose_pulp_delta = loose_pulp_viscosity_actual - loose_pulp_viscosity_target
    target_hypo_addition = (eop_delta / 10) + (hypo_delta / 10) + (loose_pulp_delta / 10)
    hypo_addition = hypo_add_prev1 + target_hypo_addition
    return hypo_addition
